# Configurações Django

## Instalação Bibliotecas

Primeiramente é necessário instalar as bibliotecas de Python que serão utilizadas. São elas:

python-dotenv -> Biblioteca utilizada para carregar arquivos .env e conseguir ler seus dados.

psycopg2-binary -> Adaptador de banco de dados PostGreSQL, que é o tipo de banco de dados que será utilizado na Azure.

gunicorn -> Servidor HTTP WSGI, a Azure usa esse pacote para servir o Django em produção.

whitenoise -> Pacote que vai servir os arquivos estáticos do projeto em produção.

Para realizar a instalação desses pacotes, copie e cole o bloco de texto abaixo no seu arquivo requeriments.txt. 
Se o arquivo de requirements não está presente no diretório de projeto é necessário gerar esse arquivo rodando o 
comando: 

``` pip freeze > requirements.txt ```


```
python-dotenv
psycopg2-binary
gunicorn
whitenoise
```

Por fim, é necessário apenas rodar ```pip install -r requirements.txt``` para realizar a instalação.

## Criando Feature Flag de Produção

Primeiramente vamos criar um arquivo .env na root do projeto. Esse tipo de arquivo tem o propósito de guardar dados do projeto 
que não devem ser expostos ao público, no caso desse projeto o arquivo .env terá somente um valor, escrito abaixo, que será utilizado como uma feature flag para que o Django possa alternar entre ambiente de desenvolvimento e de produção.

```TARGET_ENV=Dev ```

No arquivo settings.py iremos nos utilizar do pacote python-dotenv para carregar esse arquivo .env e criar a nossa feature flag 
baseada no valor da key TARGET_ENV. No seu arquivo settings.py você deve encontrar os trechos abaixo:

```
# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '<A SECRET KEY DO SEU PROJETO>'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = []
```

...

```
# Database
# https://docs.djangoproject.com/en/4.2/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}
```

É importante salvar a ```SECRET_KEY``` do seu projeto em algum lugar (num arquivo texto temporário, por exemplo). Em seguida você deve apagar ambos os trechos, substituindo-os pelo código alterado para a criação da feature flag, disponível no bloco abaixo (não se esqueça de substituir o marcador <A SECRET KEY DO SEU PROJETO> pela ```SECRET_KEY``` original do seu projeto):

```
from pathlib import Path
import os
from dotenv import load_dotenv

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

load_dotenv(BASE_DIR / '.env')

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/4.2/howto/deployment/checklist/

TARGET_ENV = os.getenv('TARGET_ENV')
NOT_PROD = not TARGET_ENV.lower().startswith('prod')

if NOT_PROD:
    # SECURITY WARNING: don't run with debug turned on in production!
    DEBUG = True
    # SECURITY WARNING: keep the secret key used in production secret!
    SECRET_KEY = '<A SECRET KEY DO SEU PROJETO>'
    ALLOWED_HOSTS = []
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }
else:
    SECRET_KEY = os.getenv('SECRET_KEY')
    DEBUG = os.getenv('DEBUG', '0').lower() in ['true', 't', '1']
    ALLOWED_HOSTS = os.getenv('ALLOWED_HOSTS').split(' ')
    CSRF_TRUSTED_ORIGINS = os.getenv('CSRF_TRUSTED_ORIGINS').split(' ')

    SECURE_SSL_REDIRECT = \
        os.getenv('SECURE_SSL_REDIRECT', '0').lower() in ['true', 't', '1']

    if SECURE_SSL_REDIRECT:
        SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': os.environ.get('DBNAME'),
            'HOST': os.environ.get('DBHOST'),
            'USER': os.environ.get('DBUSER'),
            'PASSWORD': os.environ.get('DBPASS'),
            'OPTIONS': {'sslmode': 'require'},
        }
    }
    
# Application definition

```

No código acima, foi utilizado do pacote dotenv para ler o valor de TARGET_ENV do arquivo .env e checar se o projeto está rodando em um 
ambiente de desenvolvimento ou de produção. Iremos configurar nossa aplicação para não possuir um arquivo .env no ambiente de produção. Nesse caso o sistema passará a buscar as propriedades em variáveis de ambiente.

No caso de ser um ambiente de desenvolvimento, o Django irá rodar com sua configuração padrão, no caso de ser um ambiente de produção ele muda para as configurações que serão utilizadas em produção, como a mudança de banco de dados para PostGreSQL. Nota-se que no caso de ambiente de produção existem mais keys sendo lidas, isso ocorre porque essas variáveis serão configuradas dentro do ambiente da Azure.

OBS: Note que em ambos os casos é definido o DATABASE, que por padrão é definido mais perto do final do arquivo settings.py. Como 
ele estará sendo definido antes no arquivo, é necessário apagar a definição padrão para que não ocorra conflitos.

## Configurando o whitenoise

Para que o whitenoise seja configurado corretamente é necessário realizar algumas mudanças no arquivo settings.py. Primeiramente temos 
que adicionar o whitenoise em nossa lista de aplicativos e middlewares conforme o código abaixo:

```
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    #Adicionar whitenoise na lista de aplicativos instalados
    "whitenoise.runserver_nostatic",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    # Add whitenoise middleware after the security middleware                             
    'whitenoise.middleware.WhiteNoiseMiddleware',
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]
```
Por fim, é realizado o ajuste nos diretórios de arquivos estáticos:

```
# STATIC_URL = "static/"
STATIC_URL = os.environ.get('DJANGO_STATIC_URL', "/static/")
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

STATICFILES_STORAGE = ('whitenoise.storage.CompressedManifestStaticFilesStorage')
```

O projeto Django agora está pronto para o deployment.

# Deployment na Azure
    
Antes de criar a WebApp, faça a criação do branch de produção no GitHub, pois ele será necessário durante o primeiro deployment da aplicação.

## Criando o WebApp

Na página inicial da Azure, vamos selecionar App Services, create e selecionar um Web App.

![image](https://user-images.githubusercontent.com/111078608/271293751-18ff5077-c6c0-4b59-a65b-d75de8e7fe6a.png)

Na tela de criação de WebApp, vamos selecionar a subscription Azure for Students ou a Subscription 1.
No input de resource group, vamos criar um novo com um nome que desejar.
Continuamos escolhendo um nome para nosso webapp, selecionando o método de publicação como code, a runtime stack deve ser Python 3.11 
, a região é indicado selecionar Brasil para ter tempo de loading menor.

Na seção de pricing plan fica selecionado por padrão o Basic B1, deve ser alterado para o Free F1 para que o nosso webapp esteja no free tier.

![image](https://user-images.githubusercontent.com/111078608/271300797-7be0a6ae-ceb3-4bc6-a9f4-0af6e74adaf9.png)

Podemos continaur clicando em Review + Create e na página seguinte confirmar a criação do app. Ao criar o web app a Azure irá tentar dar
 deploy. Quando o deploy for finalizado clice em "go to resource".
 
![image](https://user-images.githubusercontent.com/111078608/271311728-5bc6c0a5-0cf4-4c5b-ae6e-63a547de7430.png)

Na página de nosso webapp vamos primeiramente para o deployment center (1), e lá vamos selecionar nossa source como Github.

![image](https://user-images.githubusercontent.com/111078608/271314883-79858ca5-5dd4-4408-a6e8-31fbeccceb54.png)

Após autorizar que a Azure tenha acesso ao seu github, deve-se selecionar seu repositório e escolher a branch que será utilizada em produção.

Após esses passos é so clicar em save. Depois de salvo, a azure irá criar um arquivo de workflow na sua branch de produção e irá tentar dar 
deploy em seu projeto. Muito provavelmente o deploy irá falhar pois é necessário fazer alguns ajustes manuais.

Vá para seu repositório no Github, selecione a branch de produção, e dentro da pasta .github/workflows deve existir um arquivo de extensão 
.yml que foi gerado pela Azure. Vamos editar este arquivo para que o nosso deploy consiga ser feito com sucesso.

Primeiramente vamos alterar a seção de instalação de dependências. Por padrão o nosso arquivo requirements.txt está dentro do diretório de nosso 
projeto e não na root do repositório, logo a seção de instalação de dependências deve ficar da seguinte forma:

```
 - name: Install dependencies
        run: pip install -r SEUPROJETODJANGO/requirements.txt
```
Onde SEUPROJETODJANGO é o nome do seu projeto criado no django. 

Após a instalação de dependências deve-se criar uma seção para limpar os arquivos que podem gerar conflitos no deploy da azure, 
como o arquivo do db e o .env criado anteriormente.

```
- name: Cleaning testing files
        run: |
          cd SEUPROJETODJANGO/
          rm db.sqlite3
          rm .env
          cd ..
```

E, por fim, a última alteração em nosso workflow é na seção de compactação de artefatos para posterior upload. Devemos redefinir o processo de compactação da seguinte forma:

```
      - name: Zip artifact for deployment
        run: |
          cd SEUPROJETODJANGO/
          zip release.zip ./* -r
          cd ..
          mv SEUPROJETODJANGO/release.zip .
```

Após dar commit nessas alterações, o Azure deve dar deploy em sua aplicação com sucesso, mas isso não é tudo, ainda falta configurar 
o nosso banco de dados e as variáveis de ambiente.

## Criando o Banco de Dados PostGreSQL

Criando uma nova aba para a home da Azure, vamos pesquisar pelo Azure Database for PostgreSQL flexibe servers.

![image](https://user-images.githubusercontent.com/111078608/271321373-c0fa7a94-a57c-49af-a2fa-37d1382db330.png)

Clique em create para criar um novo servidor postgres.

![image](https://user-images.githubusercontent.com/111078608/271322937-e4b077b3-b241-40ab-a4c2-2d42e9a88c39.png)

Na tela de criação do servidor vamos utilizar as seguintes configurações: 

Na parte de Subscription e resource group vamos utilizar o mesmo que utilizamos para o nosso webapp.
Devemos escolher um nome para nosso servidor e escolher a região (de preferência Brasil).

No workload type devemos mudar para DEVELOPMENT, que irá funcionar de forma totalmente grátis até 750 horas e 32Gb de armazenamento.

Na parte de autenticação deve-se criar um usuário e senha, anote esses dados pois esse usuário e senha serão utilizados posteriormente para configurar o acesso de nosso webapp ao servidor do banco de dados.

Podemos prosseguir para a aba de Networking.

![image](https://user-images.githubusercontent.com/111078608/271324888-44d5ba84-0fec-436e-8df5-288f3b6f4b09.png)

Nesta seção vamos habilitar a checkbox de Allow public access e vamos adicionar a regra de firewall de autorizar os IPs de 0.0.0.0 até 
255.255.255.255 (Essa configuração abre o nosso servidor para que qualquer origem possa se conectar a ele, numa aplicação real isso 
não é indicado, mas vamos utilizar isso para fins acadêmicos).

Por fim clique em Review+Create e crie o servidor. A Azure vai dar deploy no servidor e após o deployment finalizar clique em go to resource.

![image](https://user-images.githubusercontent.com/111078608/271328625-a8f5f4a5-9749-47bb-95f4-9c26f6365ce4.png)

Nesta página clique em Databases, no menu lateral, depois clique em Add, insira o nome do seu banco de dados e clique em save.

O seu banco de dados foi criado e agora podemos prosseguir para a última etapa.

## Configurações Finais

Voltando para a página de Overview de nosso webapp. Vamos configurar nossas variáveis de ambiente.

![image](https://user-images.githubusercontent.com/111078608/271329917-8f96140b-258c-40b4-a4ec-d97caf9e18b6.png)

No menu lateral clique em **Variáveis de Ambiente** (a Azure criou uma opção nova, deixando a imagem diferente), e depois na seção de application settings clique em Advanced Edit. 

Uma janela de edição irá abrir, sobreescreva o conteúdo dessa janela com o que está no bloco abaixo:

```
[
  {
    "name": "ALLOWED_HOSTS",
    "value": "localhost 127.0.0.1 [::1] URLDOAPP",
    "slotSetting": false
  },
  {
    "name": "CSRF_TRUSTED_ORIGINS",
    "value": "https://URLDOAPP",
    "slotSetting": false
  },
  {
    "name": "DBHOST",
    "value": "URL DO BANCO",
    "slotSetting": false
  },
  {
    "name": "DBNAME",
    "value": "NOME DO BANCO",
    "slotSetting": false
  },
  {
    "name": "DBPASS",
    "value": "SENHA$",
    "slotSetting": false
  },
  {
    "name": "DBUSER",
    "value": "USUARIO",
    "slotSetting": false
  },
  {
    "name": "DEBUG",
    "value": "1",
    "slotSetting": false
  },
  {
    "name": "SCM_DO_BUILD_DURING_DEPLOYMENT",
    "value": "1",
    "slotSetting": false
  },
  {
    "name": "SECRET_KEY",
    "value": "GERAR UMA",
    "slotSetting": false
  },
  {
    "name": "SECURE_SSL_REDIRECT",
    "value": "0",
    "slotSetting": false
  },
  {
    "name": "TARGET_ENV",
    "value": "Prod",
    "slotSetting": false
  }
]
```
Onde devem ser alterados os valores, para os valores relativos ao projeto criado. Em ALLOWED_HOSTS e CSRF_TRUSTED_ORIGINS onde está URLDOAPP deve ser substituido pela url do webapp (disponível na seção de Overview do WebApp), DBHOST deve ter como value a url do servidor postgreSQL criado (disponível na seção de Overview do servidor), DBNAME deve ter como value o nome do banco de dados criado, e DBNAME e DBPASS são o usuário e senha que foram gerados durante a criação do servidor. O campo ```SECRET_KEY``` deve ter um valor de uma secret key que deve ser gerada (não há muitas restrições quanto a isso, geralmente é uma chave aleatória gerada algum algoritmo de criptografia, para esse propósito existem algumas ferramentas online, por ex: https://djecrety.ir/).

Ao terminar de alterar o Application Settings, é necessário clicar em Save para que as alterações sejam registradas.

Por fim, é necessário gerar as migrações de banco de dados.

![image](https://user-images.githubusercontent.com/111078608/271379007-f21592c6-579a-4b7d-b7d1-187a4234849c.png)

Primeiramente deve-se procurar por SSH no menu lateral, dentro da seção de Development Tools e clicar em Go. Uma nova aba será aberta com um terminal que está conectado diretamente ao ambiente de deployment do projeto. É necessário aguardar alguns minutos para que a conexão SSH seja realizada, e uma tela como esta seja apresentada:

![image](https://user-images.githubusercontent.com/111078608/271380140-3f2e0bd3-da67-4ffc-b5e8-3495cc41faec.png)

É necessário rodar 2 comandos: ```python manage.py makemigrations``` e ```python manage.py migrate``` para que os modelos definidos no projeto Django sejam criados dentro do banco de dados da azure. Esse processo de rodar a migração via SSH na Azure deve ser feito toda vez que for realizada alguma alteração em arquivos models do projeto. A partir de agora a aplicação deve estar funcionando na url do webapp!

