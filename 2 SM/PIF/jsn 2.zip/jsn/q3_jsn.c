#include <stdio.h>

int main(void){
	unsigned int  a, i, j;
	
while(1){
		
	scanf("%d", &a);
	int matriz[a][a];
		
	if (a!=0){
		for (i=0;i<a;i++){
			for(j=0;j<a;j++){
				if(i==j){
					matriz[i][j]=1;
				}else if (i<j){
					matriz[i][j]=(j-i+1);
				}else if(i>j){
					matriz[i][j]=(i-j+1);
					}
				}
			}
        for (i=0;i<a;i++){
			for (j=0;j<a;j++){
				if (j==0){
					printf("%3d",matriz[i][j]);
					}else{
					printf(" %3d",matriz[i][j]);
					}
				 }
				 printf("\n");
			 }
			 printf("\n");
		}
		else{
			break;	
		}
	}
	return 0;
}