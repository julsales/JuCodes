#include <stdio.h>


int main(void){
	int num,conti=0,contp=0,i,j,k;
	int par[5]={0},impar[5]={0};
	for (i=0; i<15; i++){
		scanf("%d", &num);
		if (num%2==0){
			par[contp]=num;
			contp=contp+1;
		}else{
			impar[conti]=num;
			conti=conti+1;
		}if(contp==5){
			contp=0;
 	       for(j=0; j<5;j++){
			printf("par[%d] = %d\n",j,par[j]);	
			}
		}if(conti==5){
			conti=0;
 	       for(k=0; k<5;k++){
			printf("impar[%d] = %d\n",k,impar[k]);	
			}
	}
}for (i=0;i<conti;i++){
	printf("impar[%d] = %d\n",i,impar[i]);
}for (i=0;i<contp;i++){
	printf("par[%d] = %d\n",i,par[i]);
}
return 0;
}