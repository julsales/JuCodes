#include <stdio.h>

int main(void){
	double M[12][12],soma=0;
	float valor, media;
	int i,j,cont=0;
	char O;
	
	scanf("%s",&O);
	for(i=0;i<12;i++){
		for(j=0;j<12;j++){
			scanf("%f", &valor);
			M[i][j]=valor;
			if(j>i){
				soma=soma+M[i][j];
				cont++;
			}
		}
	}
	switch (O){
		case 'S':
			printf("%.1f\n",soma);
			break;
		case 'M':
			media=soma/cont;
			printf("%.1f\n",media);
			break;
	}
return 0;
}