#include <stdio.h>

int main(void){
int a,i=0,j=0, n1, n2, soma=0,temp;
scanf("%d", &a);
while(i<a){
  scanf("%d %d", &n1, &n2);
  if (n1>n2){
    temp=n1;
     n1=n2;
        n2=temp;
  }
  for (j=(n1+1); j<n2; j++){
    if (j%2==1){
      soma=soma+j;
    }
  }printf("%d\n",soma);
  soma=0;
  i++;
}
return 0;
} 