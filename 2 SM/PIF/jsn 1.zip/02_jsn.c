#include <stdio.h>

int main() {
int Q,V;
float P;
scanf("%d %d", &V, &Q);
if (V==1){
P=(4.0*Q);
  }else if (V==2){
P=(4.5*Q);
}else if (V==3){
P=(5.00*Q);
}else if (V==4){
P=(2.00*Q);
}else if(V==5){
P=(1.50*Q);
}
printf("Total: R$ %.2f\n", P);
return 0;
}