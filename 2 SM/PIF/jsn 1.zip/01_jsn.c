#include <stdio.h>

int main() {

int L=12;
float T, V;
scanf("%f %f", &T, &V);
printf("%.3f\n", (T*V)/L);

return 0;
} 
