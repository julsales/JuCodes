#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct node {
    char nome[21];
    char comportamento;
    struct node *next;
};

void add(struct node **head, char *nome, char comportamento) {
    struct node *temp;
    struct node *novo = malloc(sizeof(struct node));
    strcpy(novo->nome, nome);
    novo->comportamento = comportamento; 
    novo->next = NULL;

    if (*head == NULL) {
        *head = novo;
    } else if ((*head)->next == NULL || strcmp(nome, (*head)->nome) < 0) {
        novo->next = *head;
        *head = novo;
    } else {
        temp = *head;
        while ((temp->next != NULL) && strcmp(temp->next->nome, nome) < 0){
            temp = temp->next;
        }
        novo->next = temp->next;
        temp->next = novo;
    }
}

int main(void) {
    struct node *head = NULL;
    int vezes, cont = 0, cont2 = 0; 
    char comportamento;
    char nome[21];

    scanf("%d", &vezes);

    for (int i = 0; i < vezes; i++) {
        scanf(" %c %s", &comportamento, nome); 
        add(&head, nome, comportamento);
    }
    struct node *temp = head;
    
    while (temp != NULL) {
        printf("%s\n", temp->nome); 
        if(temp->comportamento == '+'){
            cont++;
        }else{
            cont2++;
        }
        temp = temp->next;
    }
    printf("Se comportaram: %d | Nao se comportaram: %d\n",cont,cont2);

    temp = head;
    while (temp != NULL) {
        struct node *next = temp->next;
        free(temp);
        temp = next;
    }

    return 0;
}
