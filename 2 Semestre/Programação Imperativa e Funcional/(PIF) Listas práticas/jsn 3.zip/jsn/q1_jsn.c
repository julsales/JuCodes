#include <stdio.h>

int main() {
  int i,n, num, contt, contf, contm, caso=0;
  char sex;
  while(scanf("%d\n", &n) != EOF){
    if(caso>0){
      printf("\n");
    }
    contf=0;
    contm=0;
    while (scanf("%d %c", &num, &sex) == 2){
      if(num == n){
        if (sex=='F'){
          contf++;
        }else if (sex=='M'){
          contm++;
        }
      }if (getchar()=='\n'){
        break;
      }
    }
    caso++;
    contt=contf+contm;
    printf("Caso %d:\n", caso);
    printf("Pares Iguais: %d\n", contt);
    printf("F: %d\n", contf);
    printf("M: %d\n", contm);
  }
    return 0;
}