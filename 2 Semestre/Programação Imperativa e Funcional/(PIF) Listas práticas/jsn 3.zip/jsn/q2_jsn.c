#include <stdio.h>
#include <string.h>

int main(){
  int cont=0,cont2=0,i;
  char ch;

     while((ch=getchar()) != EOF){
      if(ch=='_'){
        cont2++;
        if (cont2==1){
            printf("<i>");
        }if (cont2==2){
            printf("</i>");
            cont2=0;
        }
      }
      else if(ch=='*'){
        cont++;
        if (cont==1){
            printf("<b>");
        }if (cont==2){
            printf("</b>");
            cont=0;
        }
      }else{
        printf("%c",ch);
      }
    }
  return 0;
}