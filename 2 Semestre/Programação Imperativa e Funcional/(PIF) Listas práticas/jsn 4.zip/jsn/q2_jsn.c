#include <stdio.h>
#include <string.h>

typedef struct{
  char nome[30];
  char assinatura[30];
}aluno;

int main(void){
  aluno aluno1[100];
  aluno sala[100];
  int N,N2,len,cont2;

  while (1){
    scanf("%d",&N);
    if (N==0){
      break;
    }
    else{
      for(int i=0;i<N;i++){
        scanf("%s %s",aluno1[i].nome,aluno1[i].assinatura);
      }
    }
    scanf("%d",&N2);
    for(int i=0;i<N2;i++){
      scanf("%s %s",sala[i].nome,sala[i].assinatura);
      len=strlen(sala[i].assinatura);
      for(int j=0;j<N;j++){
        if (strcmp(aluno1[j].nome,sala[i].nome)==0){
          len=strlen(aluno1[j].assinatura);
          int cont=0;
          for(int k=0;k<len;k++){
            if (aluno1[j].assinatura[k]!=sala[i].assinatura[k]){
              cont++;
            }
          }
          if (cont>1){
            cont2++;
            break;
          }
        }
      }
    }
    printf("%d\n",cont2);
    cont2=0;
  }
  return 0;
}