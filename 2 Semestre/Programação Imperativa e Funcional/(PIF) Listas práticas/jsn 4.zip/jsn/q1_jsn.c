#include <stdio.h>
#include <string.h>

struct frutas{
  char nome[100];
  double preco;
};

int main(void){
  int N,Q,C,quant;
  
  scanf("%d",&N);
  for (int i=0; i<N; i++){
    struct frutas fruta[100];
    scanf("%d",&Q);
    for (int i=0; i<Q; i++){
      scanf("%s %lf",fruta[i].nome,&fruta[i].preco);
    }
    scanf("%d",&C);
    float total=0;
    char compras[100];
    for (int i=0;i<C;i++){
      scanf("%s %d",compras,&quant);
      for(int j=0;j<Q; j++){
        if(strcmp(compras,fruta[j].nome)==0){
          total += (fruta[j].preco*quant);
          break;
        }
      }
    }
    printf("R$ %.2lf\n",total);
  }
  return 0;
}