#include <stdio.h>

int checagem(int num){
	if (num%7==0){
		return 1;
	}
	while (num!=0){
		if(num%10==7){
		return 1;
		}
		num=num/10;
	}
	return 0;
}

int main(void){
    int n, m, k;

    while (1) {
        scanf("%d %d %d", &n, &m, &k);
        if (n == 0 && m == 0 && k == 0) {
            break;
        }
        if (n<2 || n>100 || m<1 || m>100 || k<1 || k>100) {
		printf("%d", -1);
		continue;
		}
		else{
        int i = 1;
        int matrizp[100];
        int palmas = 0;
        int P = 1;
        int ci = 1;
        while (palmas != k) {
            matrizp[i] = P;
            P = P + ci;
            if (P == n || P == 1) {
                ci = -ci;
            }
            if ((matrizp[i] == m) && (checagem(i)==1)) {
                palmas++;
            }
            if (palmas == k) {
                printf("%d\n", i);
                break;
            }
            i++;
		}
	}
}
    return 0;

}


