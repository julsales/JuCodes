#include <stdio.h>

void matrizinput(int linhas, int colunas, int matriz[linhas][colunas]){
	for(int i=0;i<linhas;i++){
		for(int j=0;j<colunas;j++){
			scanf("%d",&matriz[i][j]);
		}
	}
}
int main(void){
	int i,j,k;
	int g, a, m, c;
	scanf("%d %d %d %d",&g, &a, &m, &c);
	int A[g][a], B[a][m], C[m][c];
	
	matrizinput(g,a,A);
	matrizinput(a,m,B);
	matrizinput(m,c,C);
	
	int m1[g][m];
	for(i=0;i<g;i++){
		for(j=0;j<m;j++){
			m1[i][j]=0;
			for(k=0;k<a;k++){
				m1[i][j]+=A[i][k]*B[k][j];
			}
		}
	}
	int m2[g][c];
	for(i=0;i<g;i++){
		for(j=0;j<c;j++){
			m2[i][j]=0;
			for(k=0;k<m;k++){
				m2[i][j]+=m1[i][k]*C[k][j];	
			}
		}
	}
	int espaco[c];
    for(i=0; i<c;i++){
        espaco[i]=0;
    }
    int num, espacoAux;
    for (i = 0; i < c; i++) {
        for (j = 0; j < g; j++) {
            num = m2[j][i];
            espacoAux = 0;
            while (num != 0) {
                num = num/10;
                espacoAux++;
            }
            if (espacoAux > espaco[i]) {
                espaco[i] = espacoAux;
            }
        }
    }
    for (i = 0; i < g; i++) {
        for (j = 0; j < c-1; j++) {
            printf("%*d ", espaco[j], m2[i][j]);
        }
        printf("%*d\n", espaco[c-1], m2[i][c-1]);
    }

    return 0;
 
}