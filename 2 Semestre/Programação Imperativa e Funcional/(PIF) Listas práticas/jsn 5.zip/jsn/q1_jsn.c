#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct{
  char nome[100];
  char cor[10];
  char tamanho[10];
}camisa;

int comp(const void *a, const void *b){
  camisa *A = (camisa *)a;
  camisa *B = (camisa *)b;
  int chara;
  chara = strcmp(A->cor, B->cor);
    if (chara != 0){
      return chara;
    }
    chara = strcmp(A->tamanho, B->tamanho);
    if (chara != 0){
      return -chara;
    }
    return strcmp(A->nome, B->nome);
  }

int main(void){
  int N, P=1;
  camisa cam[60];
  
  while (1) {
    scanf("%d", &N);
      if (N==0){
        break;
      }
      if (P){
        P = 0;
      }
      else{
        printf("\n");
      }
      for (int i = 0; i < N; ++i) {
        scanf(" %[^\n]%*c", cam[i].nome);
        scanf("%s %s", cam[i].cor, cam[i].tamanho);
      }
    qsort(cam, N, sizeof(camisa), comp);
      for (int i = 0; i < N; ++i) {
        printf("%s %s %s\n", cam[i].cor, cam[i].tamanho, cam[i].nome);
      }
  }
  return 0;
}
